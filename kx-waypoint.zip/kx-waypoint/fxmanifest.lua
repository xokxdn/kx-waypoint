fx_version "cerulean"
game "gta5"

name        "kx-waypoint"
description "Custom GPS waypoint color + marker icon"
author      "Custom Build"
version     "1.0.0"

client_scripts {
    "config.lua",
    "client.lua",
}
